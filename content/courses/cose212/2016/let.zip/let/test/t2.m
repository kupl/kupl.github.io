let x = read
in let y = read
  in let z = read
     in if iszero z then x + y else x - y

