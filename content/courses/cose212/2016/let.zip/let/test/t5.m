let x = 7 in
  let y = 2 in
    let y = (let x = x - 1 in x - y) in
      x + y

