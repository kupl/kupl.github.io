let x = read
in let y = 2
   in (x + y)

